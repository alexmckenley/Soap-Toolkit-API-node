var cfg = {
    'ServerID': 'tjcc',
    fake_port: '8008',
    wsdl_file: require('path').resolve("./ip2tele.wsdl"),
    path: '/webservice_iuim/services/QueryUserInfoServiceApply',
    site_port: 8012
}
module.exports = cfg;