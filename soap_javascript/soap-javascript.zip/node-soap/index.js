module.exports = require('./lib/soap');
